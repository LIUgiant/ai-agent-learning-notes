"""Additional offline counterexamples; do not modify the course verifier."""
import sys,json
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'9-1'))
from customer_service_env import _derive_claims_and_promises
from verifier import TrajectoryVerifier
rows=[]
for text in ['The refund is complete.', "I cannot confirm that the refund is complete."]:
 claims,promises=_derive_claims_and_promises([{'role':'assistant','content':text,'turn':1}],[])
 rows.append({'text':text,'extracted_claims':claims,'extracted_promises':promises,'expected_success_claim':text.startswith('The refund')})
fixtures=json.loads((BASE/'9-1/sample_trajectories.json').read_text())
if isinstance(fixtures,dict): fixtures=fixtures.get('trajectories',fixtures)
reports=[TrajectoryVerifier().evaluate(t) for t in fixtures]
result={'counterexamples':rows,'fixture_reports':reports,'qualification':'Deterministic fixtures, NOT additional live model trajectories. Negative sentence reveals a semantic false positive.'}
(BASE/'9-1/offline-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'claims_counts':[len(r['extracted_claims']) for r in rows],'fixtures':[(r['trajectory_id'],r['overall_score'],r['release_recommendation']) for r in reports]},ensure_ascii=False))
