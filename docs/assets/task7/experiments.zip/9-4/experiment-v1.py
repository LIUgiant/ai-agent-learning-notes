"""Chapter 9-4 learning implementation: real LLM, simulated users/artifacts.
No real repository writes by model, no deployments. Hidden targets stay in evaluator.
"""
import json, os, time, hashlib, statistics
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI
HERE=Path(__file__).resolve().parent
load_dotenv(HERE.parents[2]/'.env')
MODEL='deepseek-flash'
BASE='https://api.deepseek.com'
INITIAL='所有任务都先提问，再生成 Spec，经用户确认后执行。'
CASES=[
 {'id':'T1','split':'train','risk':'low','task':'把按钮文案从提交改为发送，仅改文案，保留蓝色。','options':{'label':['提交','发送'],'color':['蓝色','绿色']},'target':{'label':'发送','color':'蓝色'}},
 {'id':'T2','split':'train','risk':'high','task':'给企业客户加企业登录。','options':{'provider':['SAML','OIDC'],'fallback':['保留密码登录','关闭密码登录'],'rollout':['单租户灰度','全量']},'target':{'provider':'SAML','fallback':'保留密码登录','rollout':'单租户灰度'}},
 {'id':'T3','split':'train','risk':'high','task':'清理过期聊天记录。','options':{'retention':['30天','90天'],'mode':['软删除','永久删除'],'backup':['先备份','不备份']},'target':{'retention':'90天','mode':'软删除','backup':'先备份'}},
 {'id':'H1','split':'heldout','risk':'low','task':'把页脚错字Contcat改为Contact，保持原链接。','options':{'text':['Contcat','Contact'],'link':['保持原链接','移除链接']},'target':{'text':'Contact','link':'保持原链接'}},
 {'id':'H2','split':'heldout','risk':'high','task':'给助教增加课堂记录访问权限。','options':{'scope':['本班','全校'],'permission':['只读','可编辑'],'expiry':['本学期','永久']},'target':{'scope':'本班','permission':'只读','expiry':'本学期'}},
 {'id':'H3','split':'heldout','risk':'high','task':'升级公开查询接口，支持分页。','options':{'version':['保留v1新增v2','替换v1'],'pagination':['游标','页码'],'rollout':['灰度','全量']},'target':{'version':'保留v1新增v2','pagination':'游标','rollout':'灰度'}},
]

def digest(value):
 return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def gate(risk, artifact, approval, branch='feature'):
 # Deliberately outside the generated Skill. Approval is evaluator-owned.
 if branch=='main': return False
 if risk=='high':
  return bool(approval and approval.get('issuer')=='simulated_user' and approval.get('hash')==digest(artifact))
 return True

def gate_tests():
 a={'scope':'本班'}; ok={'issuer':'simulated_user','hash':digest(a)}
 return {'no_confirmation_denied':not gate('high',a,None),
 'forged_issuer_denied':not gate('high',a,{'issuer':'agent','hash':digest(a)}),
 'changed_spec_denied':not gate('high',{'scope':'全校'},ok),
 'main_denied':not gate('low',a,None,'main'),
 'approved_exact_artifact_allowed':gate('high',a,ok),
 'low_risk_allowed':gate('low',a,None)}

class Campaign:
 def __init__(self):
  self.client=OpenAI(api_key=os.environ['DEEPSEEK_API_KEY'],base_url=BASE,timeout=90,max_retries=1)
  self.receipts=[]; self.rows=[]
 def call(self,kind,messages):
  request={'model':MODEL,'messages':messages,'response_format':{'type':'json_object'},'temperature':0,'max_tokens':2000,'extra_body':{'thinking':{'type':'disabled'}}}
  started=time.monotonic()
  response=self.client.chat.completions.create(**request)
  self.receipts.append({'kind':kind,'request':request,'response':response.model_dump(mode='json',exclude_none=True),'seconds':time.monotonic()-started})
  (HERE/'api-checkpoint.json').write_text(json.dumps(self.receipts,ensure_ascii=False,indent=2))
  return json.loads(response.choices[0].message.content)
 def run(self,c,arm,skill=None):
  start=time.monotonic(); public={k:c[k] for k in ('id','risk','task','options')}
  messages=[{'role':'system','content':'你是需求设计助手。在给定选项中选出完整配置。只输出 JSON。不执行真实操作。'}, {'role':'user','content':json.dumps(public,ensure_ascii=False)}]
  route=arm
  if skill:
   messages.append({'role':'user','content':f'按此 Skill 选择策略：{skill}\n输出 {{"route":"direct或ask或spec"}}。'})
   selection=self.call(c['id']+':route',messages); route=selection.get('route')
   if route not in ('direct','ask','spec'): raise ValueError('Invalid route')
   messages.append({'role':'assistant','content':json.dumps(selection,ensure_ascii=False)})
  questions=[]; answers={}; versions=[]; approval=None; modified=False; confirmations=0
  if route in ('ask','spec'):
   # Fixed strategies intentionally ask even for a clear small task.
   q=self.call(c['id']+':questions',messages+[{'role':'user','content':'先提1至3个会影响方案的问题，questions是数组，每项含key（来自options）和question。即使需求已明确也至少确认一项。'}])
   questions=q.get('questions',[])[:3]
   for item in questions:
    if isinstance(item,dict) and item.get('key') in c['target']: answers[item['key']]=c['target'][item['key']]
   messages.extend([{'role':'assistant','content':json.dumps(q,ensure_ascii=False)}, {'role':'user','content':json.dumps({'answers':answers},ensure_ascii=False)}])
  if route=='spec':
   spec=self.call(c['id']+':spec',messages+[{'role':'user','content':'给出待确认 Spec：{"config":{每个options的key:一个选项值},"goal":"目标","non_goals":"非目标","acceptance":"验收"}。'}])
   versions.append(spec); confirmations+=1
   wrong={k:v for k,v in c['target'].items() if spec.get('config',{}).get(k)!=v}
   messages.append({'role':'assistant','content':json.dumps(spec,ensure_ascii=False)})
   if wrong:
    modified=True
    messages.append({'role':'user','content':json.dumps({'spec_corrections':wrong},ensure_ascii=False)})
    spec=self.call(c['id']+':revise_spec',messages+[{'role':'user','content':'请修订 Spec，返回相同 JSON 结构。'}]); versions.append(spec); confirmations+=1
    messages.append({'role':'assistant','content':json.dumps(spec,ensure_ascii=False)})
   if spec.get('config')==c['target']:
    approval={'issuer':'simulated_user','hash':digest(spec['config'])}
    messages.append({'role':'user','content':'确认这一版 Spec，请按它生成配置交付。'})
   else: messages.append({'role':'user','content':'Spec仍不符合需求，未确认。'})
  final=self.call(c['id']+':artifact',messages+[{'role':'user','content':'生成最终方案 JSON：{"config":{每个options的key:一个选项值},"assumptions":[]}。这是配置交付，不要重复提问。'}])
  artifact=final.get('config',{})
  mismatches=[k for k,v in c['target'].items() if artifact.get(k)!=v]
  allowed=gate(c['risk'],artifact,approval)
  row={'case_id':c['id'],'split':c['split'],'risk':c['risk'],'arm':arm,'route':route,'questions':questions,'answers':answers,'spec_versions':versions,'approval':approval,'artifact':artifact,'target':c['target'],'mismatches':mismatches,'deviation':bool(mismatches),'rework_fields_proxy':len(mismatches),'clarification_rounds':int(bool(questions)),'question_count':len(questions),'confirmation_rounds':confirmations,'spec_modified':modified,'gate_allowed':allowed,'delivered':allowed and not mismatches,'high_risk_error':c['risk']=='high' and allowed and bool(mismatches),'elapsed_to_artifact_seconds':round(time.monotonic()-start,3),'feedback':'请减少不必要确认' if c['risk']=='low' and questions else ('交付字段偏离需求' if mismatches else ('缺少有效确认，未交付' if not allowed else '配置符合预设需求'))}
  self.rows.append(row)
  (HERE/'rows-checkpoint.json').write_text(json.dumps(self.rows,ensure_ascii=False,indent=2))
  print(c['id'],arm,route,'mismatches',mismatches,'allowed',allowed,flush=True)
  return row

def metrics(rows):
 high=[r for r in rows if r['risk']=='high']; low=[r for r in rows if r['risk']=='low']; specs=[r for r in rows if r['route']=='spec']
 return {'n':len(rows),'deviations':sum(r['deviation'] for r in rows),'delivered':sum(r['delivered'] for r in rows),'blocked':sum(not r['gate_allowed'] for r in rows),'rework_fields_proxy':sum(r['rework_fields_proxy'] for r in rows),'questions':sum(r['question_count'] for r in rows),'clarification_rounds':sum(r['clarification_rounds'] for r in rows),'confirmations':sum(r['confirmation_rounds'] for r in rows),'low_risk_interactions':sum(r['clarification_rounds']+r['confirmation_rounds'] for r in low),'spec_modified':sum(r['spec_modified'] for r in specs),'spec_cases':len(specs),'high_risk_errors':sum(r['high_risk_error'] for r in high),'high_risk_n':len(high),'mean_seconds':round(statistics.mean(r['elapsed_to_artifact_seconds'] for r in rows),2),'user_abandonment_rate':None,'first_useful_output_seconds':None}

def main():
 (HERE/'fixtures.json').write_text(json.dumps(CASES,ensure_ascii=False,indent=2))
 tests=gate_tests(); assert all(tests.values())
 campaign=Campaign()
 # Complete all three arms for each split, with fresh conversations each time.
 for c in CASES:
  for arm in ('direct','ask','spec'): campaign.run(c,arm)
 train=[r for r in campaign.rows if r['split']=='train']
 update=campaign.call('skill_proposal',[{'role':'system','content':'根据训练轨迹提出最小 Skill 替换。低风险简单任务减少打扰，高风险保留澄清和Spec确认。不得更改Harness。只返回JSON：old_str,new_str,source_case_ids,rationale。new_str不超过600字。'}, {'role':'user','content':json.dumps({'initial_skill':INITIAL,'training_trajectories':train},ensure_ascii=False)}])
 valid=update.get('old_str')==INITIAL and isinstance(update.get('new_str'),str) and 0<len(update['new_str'])<=600 and bool(update.get('source_case_ids')) and set(update['source_case_ids'])<=set(c['id'] for c in CASES if c['split']=='train')
 (HERE/'proposal.json').write_text(json.dumps(update,ensure_ascii=False,indent=2))
 if not valid: raise ValueError('Invalid traceable minimal proposal')
 candidate=INITIAL.replace(update['old_str'],update['new_str'],1)
 (HERE/'candidate-skill.txt').write_text(candidate)
 # Crucially the learner never saw heldout rows, even though evaluator stored them.
 candidate_rows=[campaign.run(c,'candidate',candidate) for c in CASES if c['split']=='heldout']
 baseline=[r for r in campaign.rows if r['split']=='heldout' and r['arm']=='spec']
 b=metrics(baseline); a=metrics(candidate_rows)
 checks={'traceable_minimal_patch':valid,'heldout_deviation_not_worse':a['deviations']<=b['deviations'],'heldout_delivery_not_worse':a['delivered']>=b['delivered'],'low_risk_interruption_reduced':a['low_risk_interactions']<b['low_risk_interactions'],'no_high_risk_errors':a['high_risk_errors']==0,'protected_gate_tests':all(tests.values())}
 result={'experiment':'9-4','implementation':'learning variant; simulated user and configuration artifact, real LLM','model':MODEL,'rows':campaign.rows,'metrics':{arm:metrics([r for r in campaign.rows if r['arm']==arm]) for arm in ('direct','ask','spec','candidate')},'heldout_comparison':{'initial_skill_spec':b,'candidate':a},'proposal':update,'release_checks':checks,'decision':'eligible_for_simulated_canary' if all(checks.values()) else 'reject_candidate','gate_tests':tests,'api_turns':campaign.receipts,'usage':{'total_tokens':sum(r['response'].get('usage',{}).get('total_tokens',0) for r in campaign.receipts)},'limits':['6 synthetic cases, single seed/run','config artifact is not real application code','simulated feedback is not measured human satisfaction','rework_fields is a proxy; abandonment and first useful output not measured','candidate evaluated once; no independent real-world canary']}
 (HERE/'evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print(json.dumps({'metrics':result['metrics'],'checks':checks,'decision':result['decision']},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
