"""Run original chapter 9 logic with a DeepSeek adapter; isolate runtime/evidence."""
import sys, os, json, shutil, hashlib
from pathlib import Path
from dotenv import load_dotenv
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
load_dotenv(ROOT/'.env')
exp=sys.argv[1]
name={'9-1':'trajectory-verifier','9-3':'prompt-auto-optimization'}[exp]
source=ROOT/'chapter9'/name
work=HERE/exp
work.mkdir(exist_ok=True)
for path in source.glob('*.py'): shutil.copy2(path,work/path.name)
for path in source.glob('*.json'): shutil.copy2(path,work/path.name)
if (source/'prompts').exists(): shutil.copytree(source/'prompts',work/'prompts',dirs_exist_ok=True)
(work/'source-hashes.json').write_text(json.dumps({str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file() and (p.parent==source or p.parent.name=='prompts')},indent=2))
sys.path.insert(0,str(work))
os.environ['LLM_PROVIDER']='deepseek'
os.environ['LLM_MODEL']='deepseek-flash'
if exp=='9-1':
 import evidence_client as ec
 ec.BACKENDS['deepseek']=('DEEPSEEK_API_KEY','https://api.deepseek.com','deepseek-flash')
 from run_experiment_9_1 import build_evidence
 from customer_service_env import run_case
 from llm_judge import OpenAIQualityJudge
 from verifier import TrajectoryVerifier
 client=ec.EvidenceChatClient('deepseek','deepseek-flash')
 client.client=client.client.with_options(timeout=90,max_retries=1)
 cases=json.loads((work/'real_cases.json').read_text())
 trajectories=[]; reports=[]
 for c in cases:
  trajectories.append(run_case(c,client)); print('trajectory',c.get('id'),len(client.api_turns),flush=True)
  (work/'checkpoint.json').write_text(json.dumps({'trajectories':trajectories,'api_turns':client.api_turns},ensure_ascii=False,indent=2))
 for t in trajectories:
  reports.append(TrajectoryVerifier(OpenAIQualityJudge(evidence_client=client)).evaluate(t)); print('judge',t.get('id'),flush=True)
 evidence=build_evidence(cases,trajectories,reports,client,'python learning/task7/run_original.py 9-1')
 (work/'evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
 print(json.dumps({'acceptance':evidence['acceptance'],'usage':evidence['usage']},ensure_ascii=False,indent=2))
else:
 import config
 config._PROVIDERS['deepseek']={'base_url':'https://api.deepseek.com','key_env':'DEEPSEEK_API_KEY','default_model':'deepseek-flash'}
 original=config.record_completion
 def record(client,**kw):
  kw["extra_body"]={"thinking":{"type":"disabled"}}
  r=original(client.with_options(timeout=90,max_retries=1),**kw)
  (work/'api-checkpoint.json').write_text(json.dumps(config.get_api_turns(),ensure_ascii=False,indent=2))
  return r
 config.record_completion=record
 from demo import main
 main(rounds=3,output=str(work/'evidence.json'))
