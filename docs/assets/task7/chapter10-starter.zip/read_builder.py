"""Offline executable source reading: no external model, audio, or tool side effects."""
import json
import sys
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT/'chapter10/multi-role-transfer'))
from orchestrator import MultiRoleOrchestrator
from skill_orchestrator import SkillOrchestrator

transfer = MultiRoleOrchestrator(client=None, verbose=False)
transfer.history = [{'role':'user','content':'计算 2+3，再写一句结论。'}]
before = transfer._messages_for_api()
tools_before = [t['function']['name'] for t in transfer._tools_for_current_role()]
transfer.current_role = 'data_analysis'  # Explicit offline state snapshot, not an actual LLM handoff.
after = transfer._messages_for_api()
tools_after = [t['function']['name'] for t in transfer._tools_for_current_role()]
skill = SkillOrchestrator(client=None, verbose=False)
prefix = skill._messages_for_api()[0]
blocked = skill._handle_tool('calculate', {'expression':'2+3'})
triage = skill._handle_tool('load_skill', {'name':'triage'})
analysis = skill._handle_tool('load_skill', {'name':'data_analysis'})
calculated = skill._handle_tool('calculate', {'expression':'2+3'})
checks = {'transfer_keeps_history':before[1:]==after[1:], 'transfer_changes_system':before[0]!=after[0], 'transfer_changes_tools':tools_before!=tools_after, 'skill_fixed_system':prefix==skill._messages_for_api()[0], 'skill_preload_gate': '策略门拒绝' in blocked, 'skill_calculation': '5' in calculated}
role_report = {'mode':'offline method-level probe, no actual model handoff','checks':checks,'transfer_tools':{'before':tools_before,'after':tools_after},'skill_before_load':blocked,'skill_calculation':calculated,'loaded_skills':[x.name for x in skill.loaded_skills]}

sys.path.insert(0,str(ROOT/'chapter10/voice-werewolf'))
from werewolf.agent import PlayerAgent
from werewolf.roles import Role
from werewolf.game import Judge
# Six seats sufficient for an information-delivery probe; not a completed game.
roles=[Role.WEREWOLF,Role.WEREWOLF,Role.SEER,Role.WITCH,Role.VILLAGER,Role.VILLAGER]
players=[PlayerAgent(f'P{i+1}',role,offline=True) for i,role in enumerate(roles)]
judge=Judge(players)
judge.broadcast('公开发言','PUBLIC_PROBE:白天开始')
judge.wolves_send('狼人队友身份','WOLF_PROBE:P1与P2同队')
judge.private_send(players[2],'预言家查验结果','SEER_PROBE:P1是狼人')
actual={tag:[p.name for p in players if any(tag in m for m in p.memory)] for tag in ['PUBLIC_PROBE','WOLF_PROBE','SEER_PROBE']}
visibility_checks={'public_to_all':actual['PUBLIC_PROBE']==[p.name for p in players], 'wolf_only':actual['WOLF_PROBE']==['P1','P2'], 'seer_only':actual['SEER_PROBE']==['P3']}
report={'role_comparison':role_report,'visibility':{'mode':'offline delivery probe, not a full game or audio experiment','checks':visibility_checks,'actual_recipients':actual,'audit':[asdict(x) for x in judge.audit.records],'memories':{p.name:p.memory for p in players}}}
(HERE/'builder-probes.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
assert all(checks.values()) and all(visibility_checks.values())
print(json.dumps({'role_checks':checks,'visibility_checks':visibility_checks},ensure_ascii=False,indent=2))
