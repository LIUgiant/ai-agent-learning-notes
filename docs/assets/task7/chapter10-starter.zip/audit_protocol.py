"""Offline counterexamples: expose the trust contract, do not change course code."""
import asyncio
import json
import sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'original'))
from agents import Coordinator
from message_bus import MessageBus, Envelope
from run_starter import verify_profile

async def main():
    bus=MessageBus(verbose=False)
    manager=Coordinator(bus,'Andrew Ng')
    await manager._settle('unregistered',{'found':False,'name':'Wrong Person'})
    malformed=Envelope(sender_id='unknown',target='coordinator',type='unknown_type',payload=['not a dict'])
    positive='Andrew Ng is an Adjunct Professor. His field is machine learning.'
    def candidate(evidence,**extra):
        return {'found':True,'name':'Andrew Ng','evidence':evidence,**extra}
    checks={
        'exact_identity_quote_passes':verify_profile(candidate(positive),positive,'Andrew Ng'),
        'name_only_is_rejected':not verify_profile(candidate('Andrew Ng'),positive,'Andrew Ng'),
        'invented_quote_rejected':not verify_profile(candidate(positive+' INVENTED'),positive,'Andrew Ng'),
        'string_true_rejected':not verify_profile(candidate(positive,found='true'),positive,'Andrew Ng'),
        'wrong_name_rejected':not verify_profile(candidate(positive,name='Other Person'),positive,'Andrew Ng'),
    }
    report={'mode':'offline adversarial method probes, not real malicious worker traffic','original_manager_accepts_unverified_settle':manager.winner=='unregistered','original_envelope_accepts_wrong_payload_type':isinstance(malformed.payload,list),'supplemental_verifier_checks':checks,'qualification':'Coordinator assumes validated in-process workers; dataclass hints do not enforce wire schema. Our learning adapter validates before emitting a candidate, not a security boundary for arbitrary worker code.'}
    (HERE/'protocol-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    assert all(checks.values())
    print(json.dumps(report,ensure_ascii=False,indent=2))
asyncio.run(main())
